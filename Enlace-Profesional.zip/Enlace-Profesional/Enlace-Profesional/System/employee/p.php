<!doctype html>
<html lang="es_ES">
<body>
    <div>
    <form action="pruebaCorreo.php" method="post">
        <input id ="mail" name="mail"></input>
        <button type = "submit">enviar correo</button>
    </form>
        <button type="submit" class="btn btn-danger"><i class="fa fa-ban"></i></button>
        </form>
    </div>

    <?php
        

    ?>
</body>
</html>