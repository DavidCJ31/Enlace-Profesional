<?php
$actual_link = $_SERVER['HTTP_HOST'];

$default_timezone = '';
$smtp_host = '';
$smtp_user = '';
$smtp_pass = '';

$contact_mail = 's.calderon3010@gmail.com';

$fb  = 'https://www.facebook.com/graduadosUNA/';
$tw = 'https://twitter.com/cplatea21';
$ig = 'https://instagram.com/cplatea21';
?>