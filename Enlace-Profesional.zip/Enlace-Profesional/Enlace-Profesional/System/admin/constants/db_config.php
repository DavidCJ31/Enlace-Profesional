<?php
$servername = "localhost";
$username = "prueba";
$password = "prueba";
$dbname = "empleo";
?>