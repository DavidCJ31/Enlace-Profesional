<div style="height: 100px;">
</div>
<footer class="footer-wrapper" style="position: fixed; bottom: 0; width: 100%;">
			
	<div class="bottom-footer">
	
		<div class="container">
		
			<div class="row">
			
				<div class="col-sm-3 col-md-3">
					<p class="copy-right">&#169; Copyright <?php echo date('Y'); ?> UNA</p>
					</div>
				<!-- <div class="col-sm-3 col-md-3">
					<a  href="https://www.facebook.com/graduadosUNA/"><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
					<a  href="https://www.youtube.com/channel/UCkzyEPq_eyNKmqK6lI14c_w?view_as=subscriber"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>	
					</div> -->

				
				
				
			</div>
			</div>

		</div>
		
	</div>
</footer>