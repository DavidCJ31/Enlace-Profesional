
<?php
 echo 'Hola';
?>