<?
$servidor="10.0.2.53";
$dn="dc=una,dc=ac,dc=cr";
?>
